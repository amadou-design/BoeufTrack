# BoeufTrack Backend

## Deploy sur Railway (gratuit)

1. Va sur https://railway.app
2. "New Project" → "Deploy from GitHub repo"
3. Connecte ce repo
4. Dans "Variables" ajoute : ANTHROPIC_API_KEY = ta_cle_api
5. Railway te donne une URL genre : https://boeuftrack-xxx.railway.app

## Test local
npm install
ANTHROPIC_API_KEY=sk-ant-xxx node server.js
